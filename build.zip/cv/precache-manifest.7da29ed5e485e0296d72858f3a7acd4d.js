self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dc74f60ba29bd0c63fc4af1e74530285",
    "url": "./index.html"
  },
  {
    "revision": "c752cc69d863564d96f2",
    "url": "./static/css/3.f60fb75e.chunk.css"
  },
  {
    "revision": "c6f705fb92be09aba198",
    "url": "./static/css/main.01fa6c41.chunk.css"
  },
  {
    "revision": "0c24bc44a2443d7680a6",
    "url": "./static/js/2.01ade66a.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.01ade66a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c752cc69d863564d96f2",
    "url": "./static/js/3.0dd41a99.chunk.js"
  },
  {
    "revision": "c6f705fb92be09aba198",
    "url": "./static/js/main.59056a81.chunk.js"
  },
  {
    "revision": "5601072c56c3b129ba6a",
    "url": "./static/js/runtime-main.3aeac9e1.js"
  },
  {
    "revision": "3e86f279f30a6a8c3b1a10c0e4d0f49d",
    "url": "./static/media/bg.3e86f279.jpg"
  },
  {
    "revision": "8461907f6b7cb4189e9e821790f75498",
    "url": "./static/media/wx_head.8461907f.jpg"
  }
]);