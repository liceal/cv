self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fe3d1b8c4bd929d24ee9be94c5da7318",
    "url": "./index.html"
  },
  {
    "revision": "0d5c9879ed7f73892e3f",
    "url": "./static/css/3.f94f5115.chunk.css"
  },
  {
    "revision": "dd77a0d592e422518ec7",
    "url": "./static/css/main.01fa6c41.chunk.css"
  },
  {
    "revision": "0a495091ca995c7c1625",
    "url": "./static/js/2.c6a651d7.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "./static/js/2.c6a651d7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "0d5c9879ed7f73892e3f",
    "url": "./static/js/3.14c3cec1.chunk.js"
  },
  {
    "revision": "dd77a0d592e422518ec7",
    "url": "./static/js/main.4a6c42d5.chunk.js"
  },
  {
    "revision": "48b2ed75b665bc6fc518",
    "url": "./static/js/runtime-main.15a1eaa7.js"
  },
  {
    "revision": "3e86f279f30a6a8c3b1a10c0e4d0f49d",
    "url": "./static/media/bg.3e86f279.jpg"
  },
  {
    "revision": "8461907f6b7cb4189e9e821790f75498",
    "url": "./static/media/wx_head.8461907f.jpg"
  }
]);